from sklearn.ensemble import RandomForestRegressor

class Model:
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )

    def train(self,df, X_train, y_train):
        X_train = X_train.drop(columns=['date'])
        self.model.fit(X_train, y_train)

    def predict(self, X_test):
        X_test = X_test.drop(columns=['date'])
        return self.model.predict(X_test)
